# -*- coding: utf-8 -*-
import os, sys, json
import requests
import base64
import uuid
import random


class LineTimeline(object):
    authToken = None
    mid = None
    UA = None
    LA = None

    def __init__(self, mid, ua, app, host, tokens):
        self.mid = mid
        self.UA = ua
        self.LA = app
        self.host = host.replace("https://", "http://")
        self.tokens = tokens

    """HOMEAPI"""

    def get_detail(self, mid):
        header = {
            "Content-Type": "application/json",
            "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
            "X-Line-Mid" : self.mid,
            "x-lct" : self.tokens["channel"],
        }

        r = requests.get("%s/ma/api/v1/userpopup/getDetail.json?userMid=%s" % (self.host, mid),
                         headers=header)
        return r.json()

    def get_home(self,mid):
        header = {
                    "Content-Type": "application/json",
                    "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
                    "X-Line-Mid" : self.mid,
                    "x-lct" : self.tokens["channel"],
        }

        r = requests.get(
            "%s/mh/api/v27/post/list.json?homeId=%s&commentLimit=2&sourceType=LINE_PROFILE_COVER&likeLimit=6" % (self.host, mid),
            headers=header)
        return r.json()

    def get_cover(self,mid):
        h = self.get_home(mid)
        objId = h["result"]["homeInfo"]["objectId"]
        return "http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=%s&oid=%s" % (mid, objId)

    def upload_group_photo(self, path, mid):
        request_url = "https://obs-de.line-apps.com/os/g/%s" % mid
        cl = len(open(path, "rb").read())
        request_file = open(path, 'rb')
        header = {
            "X-Line-Application": "DESKTOPMAC\t5.1.2\tMAC\t10.9.4-MAVERICKS-x64",
            "X-Line-Access": self.tokens["obs"],
            "User-Agent": "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
            "connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        return requests.post(url=request_url, headers=header, data=request_file, verify=False).text

    def upload_cover(self, path, mid):
        #This will not work, a new object id must be made. Didn't have time to implement
        h = self.get_home(self.mid)
        objId = h["result"]["homeInfo"]["objectId"]
        request_url = "https://obs-de.line-apps.com/r/myhome/c/%s"%objId
        cl = len(open(path, "rb").read())
        request_file = open(path, 'rb')
        params = {"name":'image.jpg',
                  "oid":objId,
                  "type":"image",
                  "userid":self.mid,
                  "ver":"1.0"}
        header = {
            "Accept": "*/*",
            "X-Line-Application": "IOS\t7.17.1\tIOS\t10.2",
            "X-Line-ChannelToken": self.tokens["channel"],
            "User-Agent": "LI/7.17.1 iPad6,3 10.2",
            "Content-Type":"application/octet-stream",
            "Connection": "Keep-Alive",
            "Content-Length": str(cl),
            "x-obs-params": base64.b64encode(json.dumps(params).encode()).decode('utf-8')
        }
        return requests.post(url=request_url, headers=header, data=request_file, verify=False)

    """TIMELINE"""

    def new_post(self, text):

        header = {
            "Content-Type": "application/json",
            "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
            "X-Line-Mid" : self.mid,
            "x-lct" : self.tokens["channel"],
        }

        payload = {
            "postInfo" : { "readPermission" : { "type" : "ALL" } },
            "sourceType" : "TIMELINE",
            "contents" : { "text" : text }
        }

        r = requests.post(
            "%s/mh/api/v24/post/create.json" % (self.host),
            headers = header,
            data = json.dumps(payload)
        )

        return r.json()

    def post_photo(self,text,path):
        header = {
            "Content-Type": "application/json",
            "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
            "X-Line-Mid" : self.mid,
            "x-lct" : self.tokens["channel"],
        }

        payload = {
            "postInfo" : { "readPermission" : { "type" : "ALL" } },
            "sourceType" : "TIMELINE",
            "contents" : { "text" : text ,"media" :  [{u'objectId': u'F57144CF9ECC4AD2E162E68554D1A8BD1a1ab0t04ff07f6'}]}
        }
        r = requests.post(
            "http://%s/mh/api/v24/post/create.json" % (self.host),
            headers=header,
            data=json.dumps(payload)
        )
        return r.json()

    def activity(self, limit=20):
        header = {
            "Content-Type" : "application/json",
            "X-Line-Mid" : self.mid,
            "x-lct" : self.tokens["channel"],
        }

        r = requests.get(
            "%s/tl/mapi/v21/activities?postLimit=%s" % (self.host, limit),
            headers=header
        )
        return r.json()

    """POST LIKE&COMMENT"""

    def like(self, mid, postid, likeKey=None):
        likeType = {'hearts': 1001, 'laugh': 1002, 'thumb': 1003, 'beg': 1004, 'shock': 1005, 'cry': 1006}
        if likeKey is not None:
            like = likeType[likeKey]
        else:
            like = random.choice(likeType.values())

        header = {
            "Content-Type" : "application/json",
            "X-Line-Mid" : self.mid,
            "x-lct" : self.tokens["channel"],
        }

        payload = {
            "likeType" : like,
            "activityExternalId" : postid,
            "actorId" : mid
        }

        r = requests.post(
            "%s/mh/api/v23/like/create.json?homeId=%s" % (self.host, mid),
            headers=header,
            data=json.dumps(payload)
        )

        return r.json()

    def comment(self, mid, postid, text):
        header = {
            "Content-Type" : "application/json",
            "X-Line-Mid" : self.mid,
            "x-lct" : self.tokens["channel"],
        }

        payload = {
            "commentText" : text,
            "activityExternalId" : postid,
            "actorId" : mid
        }

        r = requests.post(
            "%s/mh/api/v23/comment/create.json?homeId=%s" % (self.host, mid),
            headers=header,
            data=json.dumps(payload)
        )

        return r.json()

    """GROUP NOTES&ALBUMS"""

    def get_group_picture(self, gid):
        res = self.get_note(gid,0,0)
        return res["result"]["homeInfo"]["groupHome"]["pictureUrl"]

    def get_album(self, gid):

        header = {
            "Content-Type" : "application/json",
            "X-Line-Mid" : self.mid,
            "x-lct": self.tokens["channel"],

        }

        r = requests.get(
            "%s/mh/album/v3/albums?type=g&sourceType=TALKROOM&homeId=%s" % (self.host, gid),
            headers = header
        )
        return r.json()

    def change_album_name(self,gid,name,albumId):
        header = {
            "Content-Type" : "application/json",
            "X-Line-Mid" : self.mid,
            "x-lct": self.tokens["channel"],

        }
        payload = {
            "title": name
        }
        r = requests.put(
            "%s/mh/album/v3/album/%s?homeId=%s" % (self.host, albumId, gid),
            headers = header,
            data = json.dumps(payload),
        )
        return r.json()

    def delete_album(self,gid,albumId):
        header = {
            "Content-Type" : "application/json",
            "X-Line-Mid" : self.mid,
            "x-lct": self.tokens["channel"],

        }
        r = requests.delete(
            "%s/mh/album/v3/album/%s?homeId=%s" % (self.host, albumId, gid),
            headers=header,
            )
        return r.json()

    def get_note(self,gid, commentLimit=6, likeLimit=6):
        header = {
            "Content-Type" : "application/json",
            "X-Line-Mid" : self.mid,
            "x-lct": self.tokens["channel"],

        }
        r = requests.get(
            "%s/mh/api/v27/post/list.json?homeId=%s&commentLimit=%s&sourceType=TALKROOM&likeLimit=%s" % (self.host, gid, commentLimit, likeLimit),
            headers=header
        )
        return r.json()

    def post_note2(self, gid, text):
        header = {
            "Content-Type": "application/json",
            "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
            "X-Line-Mid" : self.mid,
            "x-lct" : self.tokens["channel"],
        }
        payload = {"postInfo":{"readPermission":{"homeId":gid}},
                   "sourceType":"GROUPHOME",
                   "contents":{"text":text}
                   }
        r = requests.post(
            self.host + "/gb/api/v27/post/create.json",
            headers=header,
            data=json.dumps(payload)
            )
        return r.text

    def post_note(self, gid, text):
        header = {
            "Content-Type": "application/json",
            "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
            "X-Line-Mid" : self.mid,
            "X-LCT" : self.tokens["channel"],
            "X-Line-Group": gid
        }
        payload = {"postInfo":{"readPermission":{"homeId":gid}},
                   "sourceType":"GROUPHOME",
                   "contents":{"text":text}
                   }
        r = requests.post(
            "%s/nt/api/v27/post/create.json" % (self.host),
            headers=header,
            data=json.dumps(payload)
            )
        return r.json()

    def create_album(self,gid,name):
        header = {
                    "Content-Type": "application/json",
                    "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
                    "X-Line-Mid" : self.mid,
                    "x-lct" : self.tokens["channel"],
        }
        payload = {
                "type" : "image",
                "title" : name
        }
        r = requests.post(
            "%s/mh/album/v3/album?count=1&auto=0&homeId=%s" % (self.host, gid),
            headers=header,
            data=json.dumps(payload)
        )
        return r.json()

    def create_album2(self,gid,name,path,oid):
        header = {
                    "Content-Type": "application/json",
                    "User-Agent" : "DESKTOP:MAC:10.9.4-MAVERICKS-x64(5.1.2)",
                    "X-Line-Mid" : self.mid,
                    "x-lct" : self.tokens["channel"],
        }
        payload = {
                "type" : "image",
                "title" : name
        }
        r = requests.post(
            "%s/mh/album/v3/album?count=1&auto=0&homeId=%s" % (self.host, gid),
            headers=header,
            data=json.dumps(payload)
        )
        #albumId = r.json()["result"]["items"][0]["id"]


        #h = {
        #            "Content-Type": "application/x-www-form-urlencoded",
        #            "User-Agent" : self.UA,
        #            "X-Line-Mid" : gid,
        #            "X-Line-Album" : albumId,
        #            "x-lct" : self.tokens["channel"],
                    #"x-obs-host" : "obs-jp.line-apps.com:443",

        #}
        #print r.json()
        #files = {
        #    'file': open(path, 'rb'),
        #}
        #p = {
        #    "userid" : gid,
        #    "type" : "image",
        #    "oid" : oid,
        #    "ver" : "1.0"
        #}
        #data = {
        #    'params': json.dumps(p)
        #}
        #r = requests.post(
        #"http://obs-jp.line-apps.com/oa/album/a/object_info.nhn:443",
        #headers = h,
        #data = data,
        #files = files
        #)
        return r.json()

    def __repr__(self):
        return "<LineTTimeLine>"
